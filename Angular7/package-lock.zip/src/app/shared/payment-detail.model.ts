export class PaymentDetail {
  PMId: any;
  Name: any;
  TaskName: any;
  TaskId: any;
}
